﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCStore.Models.ViewModels.Account
{
    public class UserNavPartialVM
    {
        public string UserName { get; set; }
    }
}