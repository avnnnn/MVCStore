﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MVCStore.Models.Data
{
    [Table("tblRoles")]
    public class RoleDTO
    {
        public int id { get; set; }
        public string Name { get; set; }
    }
}