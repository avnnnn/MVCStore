﻿$(function () {
    $(".fancybox").fancybox();
});