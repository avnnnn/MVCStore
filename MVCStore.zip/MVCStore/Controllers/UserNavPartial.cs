﻿namespace MVCStore.Controllers
{
    internal class UserNavPartial
    {
        private string userName;

        public UserNavPartial(string userName)
        {
            this.userName = userName;
        }
    }
}