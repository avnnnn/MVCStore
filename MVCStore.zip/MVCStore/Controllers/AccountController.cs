﻿using MVCStore.Models.Data;
using MVCStore.Models.ViewModels;
using MVCStore.Models.ViewModels.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MVCStore.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            return RedirectToAction("Login");
        }
        //GET: /account/create-account
        [ActionName("create-account")]
        [HttpGet]
        public ActionResult CreateAccount()
        {
            return View("CreateAccount");
        }
        // GET: Account/Login
        [HttpGet]
        public ActionResult Login()
        {
            //account validation
            string userName = User.Identity.Name;

            if (!string.IsNullOrEmpty(userName))
                return RedirectToAction("user-profile");
            //return view
            return View();
        }
        //POST: /account/create-account
        [ActionName("create-account")]
        [HttpPost]
        public ActionResult CreateAccount(UserVM model)
        {
            // validate model 
            if (!ModelState.IsValid)
                return View("CreateAccount", model);
            //check pass. and conf. pass.
            if (!model.Password.Equals(model.ConfirmPassword))
            {
                ModelState.AddModelError("", "Password do not match");
                return View("CreateAccount", model);

            }
            using (Db db = new Db())
            {
                //check to unique user name
                if (db.Users.Any(x => x.UserName.Equals(model.UserName)))
                {
                    ModelState.AddModelError("", $"Username {model.UserName} is taken");
                    model.UserName = "";
                    return View("CreateAccount", model);
                }
                //create USerDTO

                UserDTO userDTO = new UserDTO() {
                    EmailAddress = model.EmailAddress,
                    UserName = model.UserName,
                    Password = model.Password
                };
                //add data to model
                db.Users.Add(userDTO);
                //save data
                db.SaveChanges();
                //add user role
                int id = userDTO.Id;
                UserRoleDTO userRoleDTO = new UserRoleDTO()
                {
                    UserId = id,
                    RoleId = 2
                };
                db.UserRoles.Add(userRoleDTO);
                db.SaveChanges();
                
            }
            //record in TempData
            TempData["SM"] = "You are now registered and can login";
            //redirect user
            return RedirectToAction("Login");
        }
        // POST: Account/Login
        [HttpPost]
        public ActionResult Login(LoginUserVM model)
        {
            //validate model
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //valdidate user 
            bool isValid = false;
            using(Db db = new Db())
            {
                if (db.Users.Any(x => x.UserName.Equals(model.UserName) && x.Password.Equals(model.Password)))
                    isValid = true;
                if (!isValid)
                {
                    ModelState.AddModelError("", "Invalid username or password");
                    return View(model);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(model.UserName, model.RememberMe);
                    return Redirect(FormsAuthentication.GetRedirectUrl(model.UserName, model.RememberMe));
                }
            }   
        }
        // GET: Account/Logout
        [HttpGet]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
        public ActionResult UserNavPartial()
        {
            string userName = User.Identity.Name;
            UserNavPartialVM model = new UserNavPartialVM() { UserName = userName };

            //return view
            return PartialView("_UserNavPartial", model);
        }


    }
}